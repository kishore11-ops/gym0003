import { useScrollAnimations } from '@/hooks/useScrollAnimations';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Marquee from '@/components/Marquee';
import About from '@/components/About';
import Classes from '@/components/Classes';
import Trainers from '@/components/Trainers';
import Pricing from '@/components/Pricing';
import Testimonials from '@/components/Testimonials';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

function App() {
  useScrollAnimations();

  return (
    <div className="bg-ink-950 min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Classes />
        <Trainers />
        <Pricing />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
