import { useEffect, useState } from 'react';
import { Menu, X, Dumbbell } from 'lucide-react';

const links = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Classes', href: '#classes' },
  { label: 'Trainers', href: '#trainers' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-ink-950/95 backdrop-blur-md border-b border-ink-800 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-2 group">
          <Dumbbell className="w-8 h-8 text-lime-400 group-hover:rotate-12 transition-transform duration-300" />
          <span className="font-display text-2xl tracking-wider text-white">
            IRON<span className="text-lime-400">FORGE</span>
          </span>
        </a>

        {/* Desktop links */}
        <ul className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="font-body text-sm font-600 text-ink-200 hover:text-lime-400 transition-colors duration-300 underline-grow"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#pricing"
          className="hidden lg:inline-flex items-center px-6 py-2.5 bg-lime-400 text-ink-950 font-body font-700 text-sm uppercase tracking-wider hover:bg-lime-300 transition-colors duration-300"
        >
          Join Now
        </a>

        {/* Mobile toggle */}
        <button
          className="lg:hidden text-white"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-500 ${
          open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="flex flex-col gap-4 px-6 pt-6 pb-8 bg-ink-900/98 backdrop-blur-md">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block font-body text-lg font-600 text-ink-200 hover:text-lime-400 transition-colors"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li>
            <a
              href="#pricing"
              onClick={() => setOpen(false)}
              className="inline-flex items-center px-6 py-2.5 bg-lime-400 text-ink-950 font-body font-700 text-sm uppercase tracking-wider"
            >
              Join Now
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
