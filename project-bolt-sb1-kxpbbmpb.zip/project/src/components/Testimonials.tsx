import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'David Okoro',
    role: 'Member since 2019',
    img: 'https://images.pexels.com/photos/30165254/pexels-photo-30165254.jpeg?auto=compress&cs=tinysrgb&w=200',
    text: "I went from never touching a barbell to deadlifting 405 lbs in 18 months. The coaches at Ironforge don't just hand you a program — they actually invest in your progress. This place changed my life.",
    rating: 5,
  },
  {
    name: 'Rachel Torres',
    role: 'Member since 2021',
    img: 'https://images.pexels.com/photos/10551491/pexels-photo-10551491.jpeg?auto=compress&cs=tinysrgb&w=200',
    text: "After two knee surgeries I thought my athletic days were over. Sarah's mobility program rebuilt me from the ground up. I'm now doing things I couldn't do before the injuries.",
    rating: 5,
  },
  {
    name: 'Tom Hayashi',
    role: 'Member since 2018',
    img: 'https://images.pexels.com/photos/7690459/pexels-photo-7690459.jpeg?auto=compress&cs=tinysrgb&w=200',
    text: "The community here is unlike any gym I've been to. Everyone pushes each other. I've made real friends here — we train together, compete together, and celebrate each other's wins.",
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="py-28 lg:py-36 bg-ink-950 relative overflow-hidden">
      {/* Background quote accent */}
      <Quote className="absolute top-10 right-10 w-48 h-48 text-ink-850 -rotate-12" />

      <div className="max-w-7xl mx-auto px-6 relative">
        {/* Header */}
        <div className="fade-section text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-3 mb-5">
            <span className="w-12 h-0.5 bg-lime-400" />
            <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
              Real Stories
            </span>
            <span className="w-12 h-0.5 bg-lime-400" />
          </div>
          <h2 className="font-display text-5xl lg:text-6xl text-white uppercase leading-[1]">
            Voices of
            <br />
            <span className="text-lime-400">Ironforge</span>
          </h2>
        </div>

        {/* Cards */}
        <div className="fade-stagger grid md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="lift bg-ink-900 border border-ink-800 p-8 flex flex-col"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-5">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-lime-400 fill-lime-400"
                  />
                ))}
              </div>

              <blockquote className="font-body text-ink-200 leading-relaxed flex-1 mb-8">
                "{t.text}"
              </blockquote>

              <figcaption className="flex items-center gap-4 border-t border-ink-800 pt-6">
                <img
                  src={t.img}
                  alt={t.name}
                  className="w-14 h-14 rounded-full object-cover border-2 border-lime-400"
                />
                <div>
                  <div className="font-display text-lg text-white uppercase tracking-wide">
                    {t.name}
                  </div>
                  <div className="font-body text-xs uppercase tracking-wider text-ink-400">
                    {t.role}
                  </div>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
