import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, ArrowRight } from 'lucide-react';

const contactImg =
  'https://images.pexels.com/photos/6389516/pexels-photo-6389516.jpeg?auto=compress&cs=tinysrgb&w=1260';

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <section id="contact" className="py-28 lg:py-36 bg-ink-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Info */}
          <div className="fade-left">
            <div className="flex items-center gap-3 mb-5">
              <span className="w-12 h-0.5 bg-lime-400" />
              <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
                Get Started
              </span>
            </div>

            <h2 className="font-display text-5xl lg:text-6xl text-white uppercase leading-[1] mb-6">
              Ready to
              <br />
              <span className="text-lime-400">Forge?</span>
            </h2>

            <p className="font-body text-lg text-ink-300 leading-relaxed mb-10 max-w-md">
              Book your free trial session today. Walk in, meet the coaches,
              and experience the Ironforge difference for yourself.
            </p>

            <div className="space-y-5">
              {[
                {
                  icon: MapPin,
                  label: 'Address',
                  value: '1420 Foundry Road, Suite 100, Portland, OR 97209',
                },
                {
                  icon: Phone,
                  label: 'Phone',
                  value: '(503) 555-0142',
                },
                {
                  icon: Mail,
                  label: 'Email',
                  value: 'hello@ironforgegym.com',
                },
                {
                  icon: Clock,
                  label: 'Hours',
                  value: 'Mon–Fri 5AM–11PM · Sat–Sun 7AM–8PM',
                },
              ].map((item) => (
                <div key={item.label} className="flex items-start gap-4">
                  <span className="flex-shrink-0 w-10 h-10 bg-lime-400/10 border border-lime-400/30 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-lime-400" />
                  </span>
                  <div>
                    <div className="font-body text-xs uppercase tracking-wider text-ink-400 mb-0.5">
                      {item.label}
                    </div>
                    <div className="font-body text-ink-100">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div className="fade-right">
            <div className="relative">
              <img
                src={contactImg}
                alt="Gym interior"
                className="w-full h-48 object-cover mb-6"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900 to-transparent" />
            </div>

            <form
              onSubmit={handleSubmit}
              className="bg-ink-850 border border-ink-800 p-8 space-y-5"
            >
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="block font-body text-xs uppercase tracking-wider text-ink-400 mb-2">
                    First Name
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full bg-ink-900 border border-ink-700 px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-lime-400 transition-colors"
                    placeholder="Jane"
                  />
                </div>
                <div>
                  <label className="block font-body text-xs uppercase tracking-wider text-ink-400 mb-2">
                    Last Name
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full bg-ink-900 border border-ink-700 px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-lime-400 transition-colors"
                    placeholder="Doe"
                  />
                </div>
              </div>

              <div>
                <label className="block font-body text-xs uppercase tracking-wider text-ink-400 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  required
                  className="w-full bg-ink-900 border border-ink-700 px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-lime-400 transition-colors"
                  placeholder="jane@email.com"
                />
              </div>

              <div>
                <label className="block font-body text-xs uppercase tracking-wider text-ink-400 mb-2">
                  Interested In
                </label>
                <select
                  className="w-full bg-ink-900 border border-ink-700 px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-lime-400 transition-colors"
                >
                  <option>Free Trial Session</option>
                  <option>Starter Membership</option>
                  <option>Athlete Membership</option>
                  <option>Elite Membership</option>
                  <option>Personal Training</option>
                </select>
              </div>

              <div>
                <label className="block font-body text-xs uppercase tracking-wider text-ink-400 mb-2">
                  Message
                </label>
                <textarea
                  rows={3}
                  className="w-full bg-ink-900 border border-ink-700 px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-lime-400 transition-colors resize-none"
                  placeholder="Tell us about your goals..."
                />
              </div>

              <button
                type="submit"
                className="group w-full flex items-center justify-center gap-3 py-4 bg-lime-400 text-ink-950 font-body font-700 uppercase tracking-wider hover:bg-lime-300 transition-colors duration-300"
              >
                {submitted ? 'Message Sent!' : 'Book Free Trial'}
                {!submitted && (
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
