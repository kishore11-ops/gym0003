import { Check } from 'lucide-react';

const aboutImg =
  'https://images.pexels.com/photos/38453115/pexels-photo-38453115.jpeg?auto=compress&cs=tinysrgb&w=1260';
const aboutImg2 =
  'https://images.pexels.com/photos/4761785/pexels-photo-4761785.jpeg?auto=compress&cs=tinysrgb&w=1260';

const features = [
  '16,000 sq ft of premium training space',
  'Olympic-grade racks, plates, and machines',
  'Recovery zone with sauna and ice baths',
  'Personalised programming for every member',
];

export default function About() {
  return (
    <section id="about" className="py-28 lg:py-36 bg-ink-950 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          {/* Images */}
          <div className="fade-left relative">
            <div className="relative z-10">
              <img
                src={aboutImg}
                alt="Athlete training in dimly lit gym"
                className="w-full h-[420px] lg:h-[520px] object-cover"
              />
            </div>
            <div className="absolute -bottom-10 -right-4 lg:-right-10 w-2/3 z-20 hidden sm:block">
              <img
                src={aboutImg2}
                alt="Boxer in gym"
                className="w-full h-48 lg:h-56 object-cover border-4 border-ink-950"
              />
            </div>
            <div className="absolute -top-6 -left-6 w-40 h-40 border-l-2 border-t-2 border-lime-400 -z-0" />
          </div>

          {/* Text */}
          <div className="fade-right">
            <div className="flex items-center gap-3 mb-5">
              <span className="w-12 h-0.5 bg-lime-400" />
              <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
                Who We Are
              </span>
            </div>

            <h2 className="font-display text-5xl lg:text-6xl text-white uppercase leading-[1] mb-6">
              More Than a Gym.
              <br />
              <span className="text-ink-500">A Forge.</span>
            </h2>

            <p className="font-body text-lg text-ink-300 leading-relaxed mb-6">
              Since 2012, Ironforge has been the training ground for athletes,
              first-responders, weekend warriors, and everyone in between. We
              don't do gimmicks or fads — we do results. Our coaches build
              programs around your body, your goals, and your schedule.
            </p>

            <ul className="space-y-4 mb-10">
              {features.map((f) => (
                <li key={f} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-lime-400/15 flex items-center justify-center mt-0.5">
                    <Check className="w-4 h-4 text-lime-400" />
                  </span>
                  <span className="font-body text-ink-200">{f}</span>
                </li>
              ))}
            </ul>

            <div className="grid grid-cols-3 gap-6 border-t border-ink-800 pt-8">
              {[
                { n: '12+', l: 'Years Open' },
                { n: '100K', l: 'Sessions Coached' },
                { n: '98%', l: 'Member Retention' },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-4xl text-lime-400">
                    {s.n}
                  </div>
                  <div className="font-body text-xs uppercase tracking-wider text-ink-400 mt-1">
                    {s.l}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
