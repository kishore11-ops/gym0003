import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Starter',
    price: 39,
    period: '/month',
    desc: 'Perfect for finding your footing in the gym.',
    features: [
      'Full gym access',
      '2 group classes / week',
      'Locker & shower access',
      'Fitness assessment',
      'Mobile app access',
    ],
    highlight: false,
  },
  {
    name: 'Athlete',
    price: 79,
    period: '/month',
    desc: 'For those serious about transforming their body.',
    features: [
      'Everything in Starter',
      'Unlimited group classes',
      '1 PT session / month',
      'Custom training program',
      'Recovery zone access',
      'Nutrition guidance',
    ],
    highlight: true,
  },
  {
    name: 'Elite',
    price: 149,
    period: '/month',
    desc: 'The full Ironforge experience, nothing held back.',
    features: [
      'Everything in Athlete',
      '4 PT sessions / month',
      'Priority class booking',
      'InBody composition scans',
      'Physical therapy consult',
      'Guest passes (2/month)',
    ],
    highlight: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-28 lg:py-36 bg-ink-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="fade-section text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-3 mb-5">
            <span className="w-12 h-0.5 bg-lime-400" />
            <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
              Membership
            </span>
            <span className="w-12 h-0.5 bg-lime-400" />
          </div>
          <h2 className="font-display text-5xl lg:text-6xl text-white uppercase leading-[1] mb-5">
            Choose Your Path
          </h2>
          <p className="font-body text-lg text-ink-300">
            No contracts. No hidden fees. Cancel anytime. Every plan includes
            a free 7-day trial — come see what Ironforge is all about.
          </p>
        </div>

        {/* Plans */}
        <div className="fade-stagger grid lg:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`lift relative p-8 border ${
                p.highlight
                  ? 'bg-ink-850 border-lime-400 lg:scale-105 lg:-mt-4 lg:mb-4'
                  : 'bg-ink-850 border-ink-800 hover:border-ink-600'
              }`}
            >
              {p.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-lime-400 text-ink-950 font-body text-xs font-700 uppercase tracking-wider">
                  Most Popular
                </span>
              )}

              <h3 className="font-display text-3xl text-white uppercase mb-2">
                {p.name}
              </h3>
              <p className="font-body text-sm text-ink-400 mb-6">{p.desc}</p>

              <div className="flex items-end gap-1 mb-8">
                <span className="font-display text-5xl text-lime-400">
                  ${p.price}
                </span>
                <span className="font-body text-lg text-ink-400 mb-1">
                  {p.period}
                </span>
              </div>

              <a
                href="#contact"
                className={`block text-center py-3.5 font-body font-700 uppercase tracking-wider text-sm transition-colors duration-300 ${
                  p.highlight
                    ? 'bg-lime-400 text-ink-950 hover:bg-lime-300'
                    : 'border border-ink-600 text-white hover:border-lime-400 hover:text-lime-400'
                }`}
              >
                Start Free Trial
              </a>

              <ul className="mt-8 space-y-3">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <Check
                      className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                        p.highlight ? 'text-lime-400' : 'text-ink-500'
                      }`}
                    />
                    <span className="font-body text-sm text-ink-200">{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="fade-section text-center mt-12 font-body text-sm text-ink-400">
          Student, military, and family discounts available — ask at the front desk.
        </p>
      </div>
    </section>
  );
}
