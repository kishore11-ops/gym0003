const marqueeItems = [
  'Strength Training',
  'CrossFit',
  'Boxing',
  'HIIT',
  'Olympic Lifting',
  'Powerlifting',
  'Conditioning',
  'Mobility',
  'Endurance',
  'Functional Fitness',
];

export default function Marquee() {
  const doubled = [...marqueeItems, ...marqueeItems];

  return (
    <div className="bg-lime-400 py-4 overflow-hidden border-y-2 border-ink-950">
      <div className="marquee-track flex items-center gap-8 whitespace-nowrap">
        {doubled.map((item, i) => (
          <span
            key={i}
            className="font-display text-2xl uppercase tracking-wider text-ink-950 flex items-center gap-8"
          >
            {item}
            <span className="text-ink-950/40">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
