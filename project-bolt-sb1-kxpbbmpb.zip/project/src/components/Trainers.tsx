import { Instagram, Twitter, Linkedin } from 'lucide-react';

const trainers = [
  {
    name: 'Marcus Cole',
    role: 'Head Strength Coach',
    img: 'https://images.pexels.com/photos/21633393/pexels-photo-21633393.jpeg?auto=compress&cs=tinysrgb&w=800',
    bio: 'Former national powerlifting champion with 15 years of coaching experience.',
  },
  {
    name: 'Elena Vasquez',
    role: 'CrossFit & Conditioning',
    img: 'https://images.pexels.com/photos/6739935/pexels-photo-6739935.jpeg?auto=compress&cs=tinysrgb&w=800',
    bio: 'CrossFit Games regional competitor and certified Level 3 trainer.',
  },
  {
    name: 'James Dalton',
    role: 'Boxing & Combat',
    img: 'https://images.pexels.com/photos/10960029/pexels-photo-10960029.jpeg?auto=compress&cs=tinysrgb&w=800',
    bio: 'Ex-pro boxer with 20 amateur titles. Builds fighters from the ground up.',
  },
  {
    name: 'Sarah Lin',
    role: 'Mobility & Recovery',
    img: 'https://images.pexels.com/photos/13451904/pexels-photo-13451904.jpeg?auto=compress&cs=tinysrgb&w=800',
    bio: 'Doctor of Physical Therapy specializing in athletic performance and recovery.',
  },
];

export default function Trainers() {
  return (
    <section id="trainers" className="py-28 lg:py-36 bg-ink-950 relative">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="fade-section flex flex-col lg:flex-row lg:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <span className="w-12 h-0.5 bg-lime-400" />
              <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
                The Coaches
              </span>
            </div>
            <h2 className="font-display text-5xl lg:text-6xl text-white uppercase leading-[1]">
              Built By
              <br />
              <span className="text-lime-400">The Best</span>
            </h2>
          </div>
          <p className="font-body text-lg text-ink-300 max-w-md">
            Our coaches aren't just certified — they're accomplished athletes
            who've competed at the highest level. They know what it takes
            because they've been there.
          </p>
        </div>

        {/* Grid */}
        <div className="fade-stagger grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trainers.map((t) => (
            <article key={t.name} className="lift group relative overflow-hidden">
              {/* Image */}
              <div className="relative h-80 lg:h-96 overflow-hidden">
                <img
                  src={t.img}
                  alt={t.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/30 to-transparent" />

                {/* Social icons */}
                <div className="absolute bottom-4 left-4 flex gap-2 opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-500">
                  {[Instagram, Twitter, Linkedin].map((Icon, i) => (
                    <a
                      key={i}
                      href="#"
                      className="w-9 h-9 bg-lime-400 text-ink-950 flex items-center justify-center hover:bg-white transition-colors duration-300"
                    >
                      <Icon className="w-4 h-4" />
                    </a>
                  ))}
                </div>
              </div>

              {/* Info */}
              <div className="pt-5">
                <h3 className="font-display text-2xl text-white uppercase group-hover:text-lime-400 transition-colors duration-300">
                  {t.name}
                </h3>
                <p className="font-body text-sm font-600 text-lime-400 uppercase tracking-wider mt-1">
                  {t.role}
                </p>
                <p className="font-body text-sm text-ink-400 leading-relaxed mt-3">
                  {t.bio}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
