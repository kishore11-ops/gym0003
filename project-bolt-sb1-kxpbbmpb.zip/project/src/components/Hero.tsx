import { ArrowRight, Play } from 'lucide-react';

const heroImg =
  'https://images.pexels.com/photos/17210051/pexels-photo-17210051.jpeg?auto=compress&cs=tinysrgb&w=1920';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={heroImg}
          alt="Athlete training in the gym"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/60 to-ink-950/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/80 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full pt-24">
        <div className="max-w-3xl">
          <div className="hero-anim hero-anim-delay-1 flex items-center gap-3 mb-6">
            <span className="w-12 h-0.5 bg-lime-400" />
            <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
              Strength · Conditioning · Community
            </span>
          </div>

          <h1 className="hero-anim hero-anim-delay-2 font-display text-6xl sm:text-7xl lg:text-8xl leading-[0.95] text-white uppercase">
            Forge Your
            <br />
            <span className="text-lime-400">Limits</span>
          </h1>

          <p className="hero-anim hero-anim-delay-3 mt-8 font-body text-lg lg:text-xl text-ink-200 max-w-xl leading-relaxed">
            Ironforge is where champions are built. Elite coaching,
            world-class equipment, and a community that refuses to settle.
            Your transformation starts the moment you walk through the door.
          </p>

          <div className="hero-anim hero-anim-delay-4 mt-10 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <a
              href="#pricing"
              className="group inline-flex items-center gap-3 px-8 py-4 bg-lime-400 text-ink-950 font-body font-700 uppercase tracking-wider hover:bg-lime-300 transition-all duration-300"
            >
              Start Training
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </a>
            <a
              href="#about"
              className="group inline-flex items-center gap-3 px-8 py-4 border border-ink-600 text-white font-body font-600 uppercase tracking-wider hover:border-lime-400 hover:text-lime-400 transition-all duration-300"
            >
              <Play className="w-5 h-5 fill-current" />
              Watch Intro
            </a>
          </div>

          {/* Mini stats */}
          <div className="hero-anim hero-anim-delay-5 mt-16 flex items-center gap-10">
            {[
              { n: '2,500+', l: 'Active Members' },
              { n: '45', l: 'Weekly Classes' },
              { n: '15', l: 'Expert Coaches' },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-3xl text-white">{s.n}</div>
                <div className="font-body text-xs uppercase tracking-wider text-ink-400 mt-1">
                  {s.l}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hero-anim hero-anim-delay-5">
        <div className="flex flex-col items-center gap-2">
          <span className="font-body text-xs uppercase tracking-widest text-ink-400">
            Scroll
          </span>
          <div className="w-px h-12 bg-gradient-to-b from-lime-400 to-transparent" />
        </div>
      </div>
    </section>
  );
}
