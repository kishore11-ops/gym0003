const classes = [
  {
    title: 'Strength & Power',
    desc: 'Olympic lifting, squats, presses, and progressive overload programming.',
    img: 'https://images.pexels.com/photos/931321/pexels-photo-931321.jpeg?auto=compress&cs=tinysrgb&w=800',
    tag: 'All Levels',
    schedule: 'Mon · Wed · Fri',
  },
  {
    title: 'CrossFit WOD',
    desc: 'High-intensity functional movements that build real-world strength and grit.',
    img: 'https://images.pexels.com/photos/9958671/pexels-photo-9958671.jpeg?auto=compress&cs=tinysrgb&w=800',
    tag: 'Intermediate',
    schedule: 'Tue · Thu · Sat',
  },
  {
    title: 'Boxing & Conditioning',
    desc: 'Footwork, combinations, and conditioning that forge discipline and power.',
    img: 'https://images.pexels.com/photos/4761785/pexels-photo-4761785.jpeg?auto=compress&cs=tinysrgb&w=800',
    tag: 'All Levels',
    schedule: 'Mon · Thu',
  },
  {
    title: 'Kettlebell Flow',
    desc: 'Dynamic kettlebell complexes for explosive strength, mobility, and endurance.',
    img: 'https://images.pexels.com/photos/4804337/pexels-photo-4804337.jpeg?auto=compress&cs=tinysrgb&w=800',
    tag: 'Intermediate',
    schedule: 'Wed · Sat',
  },
  {
    title: 'HIIT Inferno',
    desc: 'Short, brutal, effective. Torch calories and build cardiovascular engine.',
    img: 'https://images.pexels.com/photos/4720793/pexels-photo-4720793.jpeg?auto=compress&cs=tinysrgb&w=800',
    tag: 'Advanced',
    schedule: 'Tue · Fri',
  },
  {
    title: 'Mobility & Recovery',
    desc: 'Stretch, release, and restore. The foundation that keeps you training hard.',
    img: 'https://images.pexels.com/photos/8436610/pexels-photo-8436610.jpeg?auto=compress&cs=tinysrgb&w=800',
    tag: 'All Levels',
    schedule: 'Sun',
  },
];

export default function Classes() {
  return (
    <section id="classes" className="py-28 lg:py-36 bg-ink-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="fade-section text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-3 mb-5">
            <span className="w-12 h-0.5 bg-lime-400" />
            <span className="font-body text-sm font-600 uppercase tracking-[0.3em] text-lime-400">
              Our Programs
            </span>
            <span className="w-12 h-0.5 bg-lime-400" />
          </div>
          <h2 className="font-display text-5xl lg:text-6xl text-white uppercase leading-[1] mb-5">
            Train With Purpose
          </h2>
          <p className="font-body text-lg text-ink-300">
            Six signature programs, each led by specialist coaches. Whether
            you're chasing a first pull-up or a 500 lb deadlift, there's a
            class built for you.
          </p>
        </div>

        {/* Grid */}
        <div className="fade-stagger grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes.map((c) => (
            <article
              key={c.title}
              className="lift group relative overflow-hidden bg-ink-850 border border-ink-800 hover:border-lime-400/40"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={c.img}
                  alt={c.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-850 via-ink-850/20 to-transparent" />
                <span className="absolute top-4 left-4 px-3 py-1 bg-lime-400 text-ink-950 font-body text-xs font-700 uppercase tracking-wider">
                  {c.tag}
                </span>
              </div>

              {/* Body */}
              <div className="p-6">
                <h3 className="font-display text-2xl text-white uppercase mb-2 group-hover:text-lime-400 transition-colors duration-300">
                  {c.title}
                </h3>
                <p className="font-body text-sm text-ink-300 leading-relaxed mb-5">
                  {c.desc}
                </p>
                <div className="flex items-center justify-between border-t border-ink-800 pt-4">
                  <span className="font-body text-xs uppercase tracking-wider text-ink-400">
                    {c.schedule}
                  </span>
                  <a
                    href="#pricing"
                    className="font-body text-xs font-700 uppercase tracking-wider text-lime-400 hover:text-lime-300 transition-colors"
                  >
                    Book →
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
