import { Dumbbell, Instagram, Twitter, Youtube, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-ink-950 border-t border-ink-800 pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="#home" className="flex items-center gap-2 mb-5">
              <Dumbbell className="w-8 h-8 text-lime-400" />
              <span className="font-display text-2xl tracking-wider text-white">
                IRON<span className="text-lime-400">FORGE</span>
              </span>
            </a>
            <p className="font-body text-sm text-ink-400 leading-relaxed mb-6">
              Strength & conditioning gym. Building stronger humans since 2012.
            </p>
            <div className="flex gap-3">
              {[Instagram, Twitter, Youtube, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 border border-ink-700 flex items-center justify-center text-ink-300 hover:border-lime-400 hover:text-lime-400 transition-colors duration-300"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Explore */}
          <div>
            <h4 className="font-display text-lg text-white uppercase mb-5 tracking-wide">
              Explore
            </h4>
            <ul className="space-y-3">
              {['About', 'Classes', 'Trainers', 'Pricing', 'Contact'].map(
                (l) => (
                  <li key={l}>
                    <a
                      href={`#${l.toLowerCase()}`}
                      className="font-body text-sm text-ink-400 hover:text-lime-400 transition-colors"
                    >
                      {l}
                    </a>
                  </li>
                ),
              )}
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="font-display text-lg text-white uppercase mb-5 tracking-wide">
              Programs
            </h4>
            <ul className="space-y-3">
              {[
                'Strength & Power',
                'CrossFit WOD',
                'Boxing',
                'HIIT Inferno',
                'Mobility & Recovery',
              ].map((l) => (
                <li key={l}>
                  <a
                    href="#classes"
                    className="font-body text-sm text-ink-400 hover:text-lime-400 transition-colors"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-display text-lg text-white uppercase mb-5 tracking-wide">
              Stay Sharp
            </h4>
            <p className="font-body text-sm text-ink-400 leading-relaxed mb-4">
              Training tips, events, and members-only offers. No spam.
            </p>
            <form className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 bg-ink-900 border border-ink-700 px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-lime-400 transition-colors"
              />
              <button
                type="submit"
                className="px-5 bg-lime-400 text-ink-950 font-body font-700 uppercase text-sm hover:bg-lime-300 transition-colors"
              >
                Join
              </button>
            </form>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-ink-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-body text-xs text-ink-500">
            © 2026 Ironforge Gym. All rights reserved.
          </p>
          <div className="flex gap-6">
            {['Privacy Policy', 'Terms of Service'].map((l) => (
              <a
                key={l}
                href="#"
                className="font-body text-xs text-ink-500 hover:text-lime-400 transition-colors"
              >
                {l}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
