import { useEffect } from 'react';

/**
 * Sets up a single IntersectionObserver that toggles the `is-visible`
 * class on any element carrying one of the fade animation classes.
 * Elements fade IN when they enter the viewport and fade OUT when they
 * leave, creating the continuous fade-in/fade-out effect.
 */
export function useScrollAnimations() {
  useEffect(() => {
    const selector =
      '.fade-section, .fade-stagger, .fade-scale, .fade-left, .fade-right';

    const elements = Array.from(
      document.querySelectorAll<HTMLElement>(selector),
    );

    if (!('IntersectionObserver' in window) || elements.length === 0) {
      elements.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
          } else {
            entry.target.classList.remove('is-visible');
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: '0px 0px -80px 0px',
      },
    );

    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);
}
